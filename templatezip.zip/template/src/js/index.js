import $ from "jquery";

const render_todos = (todos) => {
    const container = $("#todosList");
    container.empty();

    todos.forEach(todo => {
        const formattedDate = new Date(todo.timestamp).toLocaleDateString('hr-HR');

        const statusIcon = todo.done
            ? '<i class="bi bi-check-circle-fill text-success fs-4"></i>'
            : '<i class="bi bi-x-circle-fill text-danger fs-4"></i>';

        const cardHtml = `
            <div class="col todo-card" style="opacity: 0; transition: opacity 0.6s ease-in;">
                <div class="card shadow-sm rounded-5 py-3 px-3 h-100 d-flex flex-column justify-content-between">
                    <div>
                        <h3 class="fw-bold">${todo.title}</h3>
                        <h6 class="text-muted">When: ${formattedDate}</h6>
                        <h6 class="mb-3">Status: ${statusIcon}</h6>
                    </div>
             
                    <div class="d-flex flex-column flex-sm-row gap-2 w-100 mt-3"> 
                        <button type="button" class="btn btn-sm btn-outline-secondary rounded-pill w-100 toggle-btn" data-id="${todo.id}">Toggle</button> 
                        <button type="button" class="btn btn-sm btn-outline-danger rounded-pill w-100 remove-btn" data-id="${todo.id}">Remove</button> 
                    </div> 
                </div>
            </div>
        `;

        container.append(cardHtml);
    });

    // Fade-in efekt
    setTimeout(() => {
        $(".todo-card").css("opacity", "1");
    }, 50);
};

const remove = (id) => {
    $.ajax({
        method: "DELETE",
        url: `/api/todos/${id}`,
        success: () => {
            get_todos();
        }
    });
};

const toggle = (id) => {
    $.get("/api/todos", (todos) => {
        const todo = todos.find(t => t.id === id);
        if (!todo) return;

        $.ajax({
            method: "PUT",
            url: `/api/todos/${id}`,
            contentType: "application/json",
            data: JSON.stringify({ done: !todo.done }),
            success: () => {
                get_todos();
            }
        });
    });
};

const get_todos = () => {
    $.get("/api/todos", (res) => {
        render_todos(res);
    });
};

// Event listeneri preko delegiranja
$(document).on("click", ".remove-btn", function() {
    const id = $(this).data("id");
    remove(id);
});

$(document).on("click", ".toggle-btn", function() {
    const id = $(this).data("id");
    toggle(id);
});

// Inicijalno učitavanje
$(() => {
    get_todos();
});