import express from 'express';
import { todos } from "./todos.js"; // 1. Uvoz podataka

const app = express();

app.use(express.static("../client/"));
app.use(express.json()); // OVO JE KLJUČNO DA SERVER PROČITA REQ.BODY
app.use(express.urlencoded({ extended: false }));

app.get("/hello", (req, res) => {
    res.send({ message: "Hello World" });    
});

app.get("/api/hello", (req, res) => {
    res.send({ message: "Hello World 2" });    
});

// Dohvat svih zadataka
app.get("/api/todos", (req, res) => {
    res.send(todos);
});

// Ruta za promjenu statusa (Toggle)
app.put("/api/todos/:id", (req, res) => {
    const { id } = req.params;
    const todo = todos.find(t => t.id === id);
    if (!todo) return res.status(404).send({ message: "Todo not found" });

    if (req.body.done !== undefined) {
        todo.done = req.body.done;
    }
    res.send({ message: "Updated", todo });
});

// Ruta za brisanje (Remove)
app.delete("/api/todos/:id", (req, res) => {
    const { id } = req.params;
    const index = todos.findIndex(t => t.id === id);
    if (index === -1) return res.status(404).send({ message: "Todo not found" });

    const [deleted] = todos.splice(index, 1);
    res.send({ message: "Deleted", todo: deleted });
});

app.listen(3000, () => {
  console.log('Server is running on http://localhost:3000');
});